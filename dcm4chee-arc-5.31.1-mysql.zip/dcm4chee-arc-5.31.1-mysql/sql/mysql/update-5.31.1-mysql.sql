create index IDXe6odcfrgswxke8wtlj8bdehet on task (exporter_id(64));

